#ifndef __MY_MOTOR_H__
#define __MY_MOTOR_H__

#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <pthread.h>
#include <unistd.h>
#include <termios.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <pthread.h>
#include <netinet/in.h>
#include <sys/time.h>
#include "../common_define.h"
#include "../common_api.h"

#endif	//__MY_MOTOR_H__

