#include "convert_ps_stream.h"

void *convert_ps_stream(void * cvt)
{
	return cvt;
}
