#ifndef __MY_CONVERT_PS_H__
#define __MY_CONVERT_PS_H__

extern void *convert_ps_stream(void * cvt);

#endif	//__MY_CONVERT_PS_H__
