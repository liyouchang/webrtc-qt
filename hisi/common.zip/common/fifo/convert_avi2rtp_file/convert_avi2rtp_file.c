#include "convert_avi2rtp_file.h"

void *convert_avi2rtp_file(void * cvt)
{
	return cvt;
}
