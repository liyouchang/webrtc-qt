#ifndef __MY_CONVERT_AVI2RTP_H__
#define __MY_CONVERT_AVI2RTP_H__

extern void *convert_avi2rtp_file(void * cvt);

#endif	//__MY_CONVERT_AVI2RTP_H__
