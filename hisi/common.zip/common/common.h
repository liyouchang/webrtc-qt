#ifndef MODULE_COMMON_H
#define MODULE_COMMON_H
#include "clock/clock.h"

#endif //MODULE_COMMON_H
