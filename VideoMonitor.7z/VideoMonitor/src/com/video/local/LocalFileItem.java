package com.video.local;

import java.util.HashMap;
import java.util.List;

public class LocalFileItem {

	/**
	 * 文件夹名
	 */
	public String fileName;
	
	/**
	 * 文件夹下的单项
	 */
	public List<HashMap<String, Object>> itemViews;
}
